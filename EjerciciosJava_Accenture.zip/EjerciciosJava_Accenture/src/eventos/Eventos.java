package eventos;

public class Eventos {
	/**
	 * Clase que representa un evento con nombre, tipo y asientos disponibles.
	 * @author Sara Thapa Kc
	 * @version 1.0
	 */
	
	// Atributos
    int id;
    String nombre;
    String tipo;
    int asientosDisponibles;

    /**
     * CONSTRUCTOR.
     * @param id: Identificador del evento
     * @param nombre: Nombre del evento
     * @param tipo: Tipo del evento
     * @param asientosDisponibles: Número de asientos disponibles
     */
    public Eventos(int id, String nombre, String tipo, int asientosDisponibles) {
        this.id = id;
        this.nombre = nombre;
        this.tipo = tipo;
        this.asientosDisponibles = asientosDisponibles;
    }
}
