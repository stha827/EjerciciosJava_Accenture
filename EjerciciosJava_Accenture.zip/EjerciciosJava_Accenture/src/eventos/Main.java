package eventos;

public class Main {
	public static void main(String[] args) {
		//Creamos el array con los eventos
		Eventos[] eventos = {
				new Eventos(1, "Eventos 1", "musical", 3),
				new Eventos(2, "Eventos 2", "deportivo", 5),
				new Eventos(3, "Eventos 3", "deportivo", 10),
				new Eventos(4, "Eventos 4", "cultural", 34),
				new Eventos(5, "Eventos 5", "deportivo", 56)
		};

		// Ejercicio 1: Mostrar nombres de todos los eventos
		System.out.println("Ejercicio 1:");
		for (int i = 0; i < eventos.length; i++) {
			System.out.println(eventos[i].nombre);
		}

		// Ejercicio 2: Mostrar nombres de eventos tipo "deportivo"
		System.out.println("\nEjercicio 2:");
		for (int i = 0; i < eventos.length; i++) {
			if (eventos[i].tipo.equals("deportivo")) {
				System.out.println(eventos[i].nombre);
			}
		}

		// Ejercicio 3: Sumar los asientos disponibles de eventos "deportivo"
		System.out.println("\nEjercicio 3:");
		int totalAsientos = 0;
		for (int i = 0; i < eventos.length; i++) {
			if (eventos[i].tipo.equals("deportivo")) {
				totalAsientos += eventos[i].asientosDisponibles;
			}
		}
		System.out.println("Total de asientos disponibles: " + totalAsientos);

		// Ejercicio 4: Mostrar IDs de eventos "deportivo"
		System.out.println("\nEjercicio 4:");
		for (int i = 0; i < eventos.length; i++) {
			if (eventos[i].tipo.equals("deportivo")) {
				System.out.println(eventos[i].id);
			}
		}

		// Ejercicio 5: Mostrar IDs de eventos "deportivo" ordenados por nombre descendente
		System.out.println("\nEjercicio 5:");

		// Copiamos solo los eventos deportivos
		Eventos[] eventosDeportivos = new Eventos[3]; 
		int posicion = 0;
		for (int i = 0; i < eventos.length; i++) {
			if (eventos[i].tipo.equals("deportivo")) {
				eventosDeportivos[posicion] = eventos[i];
				posicion++;
			}
		}

		// Ordenamos por el nombre descendente
		for (int i = 0; i < eventosDeportivos.length - 1; i++) {
			for (int j = 0; j < eventosDeportivos.length - 1 - i; j++) {
				if (eventosDeportivos[j].nombre.compareTo(eventosDeportivos[j + 1].nombre) < 0) {
					Eventos temporal = eventosDeportivos[j];
					eventosDeportivos[j] = eventosDeportivos[j + 1];
					eventosDeportivos[j + 1] = temporal;
				}
			}
		}

		// Mostramos
		for (int i = 0; i < eventosDeportivos.length; i++) {
			System.out.println(eventosDeportivos[i].id);
		}
	}
}
